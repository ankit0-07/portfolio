-- 1. Create a stored procedure to display the restaurant name, type, and cuisine where the table booking is not zero
CREATE PROCEDURE GetAvailableRestaurants
AS
BEGIN
    SELECT RestaurantName, RestaurantType, CuisinesType
    FROM Jomato
    WHERE TableBooking > 0;
END;
GO

-- Execute the procedure
EXEC GetAvailableRestaurants;

-- 2. Create a transaction to update 'Cafe' to 'Cafeteria' and rollback the transaction
BEGIN TRANSACTION;
    UPDATE Jomato
    SET CuisinesType = 'Cafeteria'
    WHERE CuisinesType = 'Cafe';

-- Check the result
SELECT * FROM Jomato WHERE CuisinesType = 'Cafeteria';

-- Rollback the transaction
ROLLBACK;

-- 3. Generate row numbers and find the top 5 areas with the highest restaurant ratings
SELECT TOP 5 Area, Rating, ROW_NUMBER() OVER (ORDER BY Rating DESC) AS RowNum
FROM Jomato
ORDER BY Rating DESC;

-- 4. Use a WHILE loop to display numbers from 1 to 50
DECLARE @Counter INT = 1;
WHILE @Counter <= 50
BEGIN
    PRINT @Counter;
    SET @Counter = @Counter + 1;
END;

-- 5. Create a view to store the top 5 highest rated restaurants
CREATE VIEW TopRatedRestaurants AS
SELECT TOP 5 RestaurantName, Rating
FROM Jomato
ORDER BY Rating DESC;

-- 6. Create a trigger to send an email when a new record is inserted
-- Drop the trigger if it already exists
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'NotifyRestaurantOwner')
    DROP TRIGGER NotifyRestaurantOwner;
GO

CREATE TRIGGER NotifyRestaurantOwner
ON Jomato
AFTER INSERT
AS
BEGIN
    DECLARE @RestaurantName NVARCHAR(MAX), @EmailBody NVARCHAR(MAX);
    
    -- Retrieve restaurant name from the inserted row
    SELECT @RestaurantName = i.RestaurantName
    FROM inserted i;
    
    -- Construct the email body
    SET @EmailBody = 'Dear Owner, ' + CHAR(13) + CHAR(10) +
                    'A new restaurant "' + @RestaurantName + '" has been added to the platform.' + CHAR(13) + CHAR(10) +
                    'Thank you for partnering with us.';

    -- Use database mail or an equivalent procedure to send the email
    EXEC msdb.dbo.sp_send_dbmail
         @profile_name = 'JomatoEmailProfile',
         @recipients = 'owner@jomato.com',
         @subject = 'New Restaurant Added',
         @body = @EmailBody;
END;
GO