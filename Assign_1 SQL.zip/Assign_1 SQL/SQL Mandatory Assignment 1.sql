-- Create Salesman Table
CREATE TABLE Salesman (
    SalesmanId INT PRIMARY KEY,
    Name VARCHAR(255),
    Commission DECIMAL(10, 2),
    City VARCHAR(255) DEFAULT 'Unknown',
    Age INT
);

-- Insert data into Salesman Table
INSERT INTO Salesman (SalesmanId, Name, Commission, City, Age)
VALUES
    (101, 'Joe', 50, 'California', 17),
    (102, 'Simon', 75, 'Texas', 25),
    (103, 'Jessie', 105, 'Florida', 35),
    (104, 'Danny', 100, 'Texas', 22),
    (105, 'Lia', 65, 'New Jersey', 30);

-- Create Customer Table
CREATE TABLE Customer (
    SalesmanId INT,
    CustomerId INT,
    CustomerName VARCHAR(255) NOT NULL,
    PurchaseAmount INT,
    FOREIGN KEY (SalesmanId) REFERENCES Salesman(SalesmanId)
);

-- Insert data into Customer Table
-- Add missing SalesmanId values to the Salesman table
INSERT INTO Salesman (SalesmanId, Name, Commission, City, Age)
VALUES 
    (107, 'Unknown', 0, 'Unknown', 0),
    (110, 'Unknown', 0, 'Unknown', 0);

-- Now insert data into Customer table
INSERT INTO Customer (SalesmanId, CustomerId, CustomerName, PurchaseAmount)
VALUES
    (101, 2345, 'Andrew', 550),
    (103, 1575, 'Lucky', 4500),
    (104, 2345, 'Andrew', 4000),
    (107, 3747, 'Remona', 2700),
    (110, 4004, 'Julia', 4545);


-- Create Orders Table
CREATE TABLE Orders (
    OrderId INT,
    CustomerId INT,
    SalesmanId INT,
    Orderdate DATE,
    Amount MONEY
);

-- Insert data into Orders Table
INSERT INTO Orders (OrderId, CustomerId, SalesmanId, Orderdate, Amount)
VALUES 
    (5001, 2345, 101, '2021-07-01', 550),
    (5003, 1234, 105, '2022-02-15', 1500);

-- 1. Insert a new record in Orders Table
INSERT INTO Orders (OrderId, CustomerId, SalesmanId, Orderdate, Amount)
VALUES (5004, 3747, 103, '2022-08-10', 3200);

-- 2. Add constraints
-- Primary Key Constraint on SalesmanId in Salesman Table is already applied in creation.
-- Default Constraint for City is already applied in creation.
-- Foreign Key Constraint for SalesmanId in Customer Table is already applied in creation.
-- NOT NULL Constraint for CustomerName is already applied in creation.

-- 3. Fetch data where CustomerName ends with 'N' and PurchaseAmount > 500
SELECT * 
FROM Customer 
WHERE CustomerName LIKE '%N' 
  AND PurchaseAmount > 500;

-- 4. Retrieve unique and duplicate SalesmanId using SET operators
-- Unique SalesmanId
SELECT SalesmanId 
FROM Salesman 
UNION 
SELECT SalesmanId 
FROM Customer;

-- Duplicate SalesmanId
SELECT SalesmanId 
FROM Salesman 
UNION ALL 
SELECT SalesmanId 
FROM Customer;

-- 5. Display specified columns with conditions
SELECT 
    O.Orderdate, 
    S.Name AS SalesmanName, 
    C.CustomerName, 
    S.Commission, 
    S.City
FROM Orders O
JOIN Salesman S ON O.SalesmanId = S.SalesmanId
JOIN Customer C ON O.CustomerId = C.CustomerId
WHERE C.PurchaseAmount BETWEEN 500 AND 1500;

-- 6. Fetch all results from Salesman and Orders using RIGHT JOIN
SELECT 
    S.SalesmanId, 
    S.Name AS SalesmanName, 
    S.City, 
    O.OrderId, 
    O.CustomerId, 
    O.Orderdate, 
    O.Amount
FROM Salesman S
RIGHT JOIN Orders O ON S.SalesmanId = O.SalesmanId;
